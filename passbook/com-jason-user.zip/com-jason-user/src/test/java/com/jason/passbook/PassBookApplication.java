package com.jason.passbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * 测试程序入口
 */
@SpringBootApplication
public class PassBookApplication {

    public static void main(String[] args) {
        SpringApplication.run(PassBookApplication.class, args);
    }
}
