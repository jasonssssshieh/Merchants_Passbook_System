package com.jason.passbook;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PassbookApplication {
    public static void main(String[] args) {
        SpringApplication.run(PassbookApplication.class, args);
    }
}
